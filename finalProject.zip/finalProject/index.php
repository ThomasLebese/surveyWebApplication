<!DOCTYPE html>
<html>
<head>
       <title>enter your personal detail</title>
       <link rel="stylesheet" = href="page.css">
       <link rel="stylesheet" = href="buttonStyle.css">
       <link rel="stylesheet" = href="styleTable.css">
</head>
<body>
<div class ="surForm"><h1> Personal details form</h1></div>
<div class = "main" > 
<form action="includes/submitInfor.inc.php" method="POST">
        <div id ="name">
            <h2 class ="name">Name</h2>
            <input class ="surname" type= "text" name ="p_surname" required> <br>
            <label class ="surLabel">Surname </label>

            <input class ="firstName" type ="text" name ="last_name" required>
            <label class ="firtsLabel"> Last Name</label>
        </div>

        <h2 class ="name">Contact details</h2>
        <input class="contactNum" type ="text" name ="contact_num" required>

        <h2 class ="name">Date</h2>
        <input class="dateS" type ="text" name ="dateS" required>

        <h2 class ="name">Age</h2>
        <input class="age" type ="text" name ="age" required>

     
    <button Class="btn btn2" onclick="NextPage()" type ="submit" name="submit"> Submit and go to the Next page</button>

    <script>
            function NextPage()
            {
             window.location = "index1.php";
            }
        </script>
</table>
</form>

</body>
</html>