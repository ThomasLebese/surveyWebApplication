<!DOCTYPE html>
<html>
<head>
       <title>Fill the survey form</title>
       <link rel="stylesheet" = href="page.css">
       <link rel="stylesheet" = href="buttonStyle.css">
</head>
<body>
<form action="includes/addActivity.php" method="POST">
<div class="surForm1"><h3>On a scale of 1 to 5 indicate whether you strongly agree to strongly disagree</h3>
<!--adding tables-->
    <br>
        <table>
            <tr>
                <th></th>
                    <th>Strongly Agree<br> (1)</th>
                    <th>Agree <br> (2)</th>
                    <th>Neutral <br>(3)</th>
                    <th>Disagree <br>(4)</th>
                    <th>Strongly disagree<br> (5)</th>
                </tr>

                    <tr>
                    <!--first row-->
                    <td>I like to eat out</td>
                    <td> <label for="myRadioId1" class= "radio">
                    <input type ="radio" name="eatOut" value = 1 id ="myRadioId1" class="radio_input">
                    <div class="radio_r"></div>
                    </label>
                    </td>
                    <td>
                    <label for="myRadioId1" class= "radio">
                    <input type ="radio" name="eatOut" value = 2  id ="myRadioId1" class="radio_input">
                    <div class="radio_r"></div>
                    </label>
                    </td>
                    <td>
                    <label for="myRadioId1" class= "radio">
                    <input type ="radio" name="eatOut" value = 3 id ="myRadioId1" class="radio_input">
                    <div class="radio_r"></div>
                    </label>
                    </td>
                    <td>
                    <label for="myRadioId1" class= "radio">
                    <input type ="radio" name="eatOut" value = 4 id ="myRadioId1" class="radio_input">
                    <div class="radio_r"></div>
                    </label>
                    </td>  
                    <td>
                    <label for="myRadioId1" class= "radio">
                    <input type ="radio" name="eatOut" value = 5 id ="myRadioId1" class="radio_input">
                    <div class="radio_r"></div>
                    </label>
                    </td> 
                    </tr>

                    <tr>
                    <td>I like to watch movies</td> 
                    <td>
                    <label for="myRadioId2" class= "radio">
                    <input type ="radio" name="watchMovies" value = 1 id ="myRadioId2" class="radio_input">
                    <div class="radio_r"></div>
                    </label>
                    </td>
                    <td>
                    <label for="myRadioId2" class= "radio">
                    <input type ="radio" name="watchMovies"  value = 2 id ="myRadioId2" class="radio_input">
                    <div class="radio_r"></div>
                    </label>
                    </td>
                    <td>
                    <label for="myRadioId2" class= "radio">
                    <input type ="radio" name="watchMovies" value = 3 id ="myRadioId2" class="radio_input">
                    <div class="radio_r"></div>
                    </label>
                    </td>
                    <td>
                    <label for="myRadioId2" class= "radio">
                    <input type ="radio" name="watchMovies" value = 4 id ="myRadioId2" class="radio_input">
                    <div class="radio_r"></div>
                    </label>
                    </td>  
                    <td>
                    <label for="myRadioId2" class= "radio">
                    <input type ="radio" name="watchMovies" value = 5 id ="myRadioId2" class="radio_input">
                    <div class="radio_r"></div>
                    </label>
                    </td> 
                    </tr>

                    <tr>
                        <td>I like to watch TV</td>
                        <td>
                            <label for="myRadioId3" class= "radio">
                                <input type ="radio" name="watchTV" value = 1 id ="myRadioId3" class="radio_input">
                                <div class="radio_r"></div>
                             </label>
                        </td>
                        <td>
                            <label for="myRadioId3" class= "radio">
                                <input type ="radio" name="watchTV" value = 2  id ="myRadioId3" class="radio_input">
                                <div class="radio_r"></div>
                             </label>
                        </td>
                        <td>
                            <label for="myRadioId3" class= "radio">
                                <input type ="radio" name="watchTV"  value = 3 id ="myRadioId3" class="radio_input">
                                <div class="radio_r"></div>
                             </label>
                        </td>
                        <td>
                            <label for="myRadioId3" class= "radio">
                                <input type ="radio" name="watchTV" value = 4  id ="myRadioId3" class="radio_input">
                                <div class="radio_r"></div>
                             </label>
                        </td>  
                        <td>
                            <label for="myRadioId3" class= "radio">
                                <input type ="radio" name="watchTV" value = 5  id ="myRadioId3" class="radio_input">
                                <div class="radio_r"></div>
                             </label>
                        </td> 
                    </tr>

                    <tr>
                        <td>I like to listen to the radio</td>
                        <td>
                            <label for="myRadioId4" class= "radio">
                                <input type ="radio" name="likeRadio" value = 1  id ="myRadioId4" class="radio_input">
                                <div class="radio_r"></div>
                             </label>
                        </td>
                        <td>
                            <label for="myRadioId4" class= "radio">
                                <input type ="radio" name="likeRadio" value = 2  id ="myRadioId4" class="radio_input">
                                <div class="radio_r"></div>
                             </label>
                        </td>
                        <td>
                            <label for="myRadioId4" class= "radio">
                                <input type ="radio" name="likeRadio" value = 3  id ="myRadioId4" class="radio_input">
                                <div class="radio_r"></div>
                             </label>
                        </td>
                        <td>
                            <label for="myRadioId4" class= "radio">
                                <input type ="radio" name="likeRadio" value = 4 id ="myRadioId4" class="radio_input">
                                <div class="radio_r"></div>
                             </label>
                        </td>  
                        <td>
                            <label for="myRadioId4" class= "radio">
                                <input type ="radio" name="likeRadio" value = 5 id ="myRadioId4" class="radio_input">
                                <div class="radio_r"></div>
                             </label>
                        </td> 
                    </tr>

                </table>

                <br>                 
    <button Class="btn btn2" onclick=homePage() type ="submit" name="submit"> Submit</button>
   
    </div>
    <script>
            function homePage()
            {
             window.location = "welcom.html";
            }
        </script>

</form>     
                </body>
</html>
