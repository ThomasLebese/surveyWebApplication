<!DOCTYPE html>
<html>
<head>
       <title>Fill the survey form</title>
       <link rel="stylesheet" = href="page.css">
       <link rel="stylesheet" = href="buttonStyle.css">
</head>
<body>
<form action="includes/addingFood.php" method="POST">
<div class="header1"><h3>What is your favourite food? (You can choose more than 1 answer)</h3></div>
                 <!--adding check boxes-->
<input type="checkbox" id="food1" name="food[]" value = "Pizza">
<label for ="food1">Pizza</label>

<input type="checkbox" id="food2" name="food[]" value = "Pasta">
<label for ="food2">Pasta</label>

<input type="checkbox" id="food3" name= "food[]" value = "Pap and Wors">
<label for ="food3">Pap and Wors</label>

<input type="checkbox" id="food4" name= "food[]" value = "Chicken stir fry">
<label for ="food4">Chicken stir fry</label>

<input type="checkbox" id="food5" name= "food[]" value = "Beef stir fry">
<label for ="food5">Beef stir fry</label>


<input type="checkbox" id="food6" name= "foood[]" value = "Other">
<label for ="food6">Other</label>

<button Class="btn btn2" onclick="NextPage()" type ="submit" name="submit"> Submit and go to the Next page</button>

<script>
        function NextPage()
        {
         window.location = "index2.php";
        }
    </script>
</form>

</body>
</html>