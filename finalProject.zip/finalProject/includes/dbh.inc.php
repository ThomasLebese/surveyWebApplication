<?php
$dbServername ="localhost";
$dbUsername ="root";
$dbPassword = "";
$dbName ="surveydatabase";

$conn = mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);
?>