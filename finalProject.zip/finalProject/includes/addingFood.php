<?php
include_once 'dbh.inc.php';

if(isset($_POST['submit']))
{
    $food =$_POST['food'];

    foreach($food as $item)
    {
        $sqlFood ="INSERT INTO foodtime (food) VALUES('$item');";
        mysqli_query($conn,$sqlFood);
    }
}

echo "<script> alert('You have choosen your favourate food '); window.location='../index2.php' </script>";

