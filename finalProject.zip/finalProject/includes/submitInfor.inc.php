<?php
include_once 'dbh.inc.php';

$p_surname= $_POST['p_surname'];
$last_name= $_POST['last_name'];
$contact_num= $_POST['contact_num'];
$dateS= $_POST['dateS'];
$age= $_POST['age'];

$sqlDe ="INSERT INTO surveytable (p_surname, last_name, contact_num, dateS, age) VALUES('$p_surname, $last_name, $contact_num, $dateS, $age')";
mysqli_query($conn,$sqlDe);

echo "<script> alert('Your personal details have been received '); window.location='../index1.php' </script>";

