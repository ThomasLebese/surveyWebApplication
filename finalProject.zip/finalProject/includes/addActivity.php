<?php
include_once 'dbh.inc.php';

$eatOut =$_POST['eatOut'];
$watchMovies =$_POST['watchMovies'];
$watchTV =$_POST['watchTV'];
$likeRadio =$_POST['likeRadio'];


$sqlAct ="INSERT INTO activity (eatOut,watchMovie,watchTV,likeRadio) VALUES('$eatOut,$watchMovies,$watchTV,$likeRadio')";
mysqli_query($conn,$sqlAct);

echo "<script> alert('Thanks for taking your time to complete the survey'); window.location='../welcom.html' </script>";