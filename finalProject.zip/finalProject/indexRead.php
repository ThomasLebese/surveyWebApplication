<?php
include_once 'includes/dbh.inc.php';
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" = href="page.css">
    <link rel="stylesheet" = href="buttonStyle.css">
    <title>Survey results</title>
</head>
<body>
  <?php

  //determine the number of survey
  $sql="SELECT count(id) AS total FROM surveytable";
  $countResult =mysqli_query($conn,$sql);
  $valueCount = mysqli_fetch_assoc($countResult);
  $num_rows=$valueCount['total'];
   
   //the age average 
   $sqlAge="SELECT SUM(age) AS totalAge FROM surveytable";
   $ageResult =mysqli_query($conn,$sqlAge);
   $valueAge = mysqli_fetch_assoc($ageResult);
   $sumAge=$valueAge['totalAge'];
   $ave = $sumAge/$num_rows;

    //determine the oldest person
    $sqlMax="SELECT MAX(age) AS ageMax FROM surveytable";
    $maxResult =mysqli_query($conn,$sqlMax);
    $valueMax = mysqli_fetch_assoc($maxResult);
    $maxAge=$valueMax['ageMax'];


     //determine the youngest person
     $sqlMin="SELECT MIN(age) AS ageMin FROM surveytable";
     $minResult =mysqli_query($conn,$sqlMin);
     $valueMin = mysqli_fetch_assoc($minResult);
     $minAge=$valueMin['ageMin'];

     //determine total of food
     $sqlFC="SELECT COUNT(foodID) AS foodNum FROM foodtime";
     $fcResult =mysqli_query($conn,$sqlFC);
     $valueFC = mysqli_fetch_assoc($fcResult);
     $countFod=$valueFC['foodNum'];
     

    //determine Percentage of people who like Pizza
     $sqlPizza="SELECT COUNT(food) AS countPizza FROM foodtime WHERE food = 'Pizza'";
     $pizzaResult =mysqli_query($conn,$sqlPizza);
     $valuePizza = mysqli_fetch_assoc($pizzaResult);
     $countPizza=$valuePizza['countPizza'];
     $perPizza=($countPizza/$countFod)*100;

      //determine Percentage of people who like Pasta
      $sqlPasta="SELECT COUNT(food) AS countPasta FROM foodtime WHERE food = 'Pasta'";
      $pastaResult =mysqli_query($conn,$sqlPasta);
      $valuePasta = mysqli_fetch_assoc($pastaResult);
      $countPasta=$valuePasta['countPasta'];
      $perPasta=($countPasta/$countFod)*100;

      //determine Percentage of people who like Pap and Wors
      $sqlPap="SELECT COUNT(food) AS countPap FROM foodtime WHERE food = 'Pap and Wors'";
      $papResult =mysqli_query($conn,$sqlPap);
      $valuePap = mysqli_fetch_assoc($papResult);
      $countPap=$valuePap['countPap'];
      $perPap=($countPap/$countFod)*100;

       //determine the the number of rows
       $sqlRows="SELECT COUNT(act_id) AS countRows FROM activity";
       $rowsResult =mysqli_query($conn,$sqlRows);
       $valueRows = mysqli_fetch_assoc($rowsResult);
       $countRows=$valueRows['countRows'];
       

       //determine the average of people who like to eat out:
       $sqlEat="SELECT SUM(eatOut) AS countEat FROM activity";
       $eatResult =mysqli_query($conn,$sqlEat);
       $valueEat = mysqli_fetch_assoc($eatResult);
       $countEat=$valueEat['countEat'];
       $eatAve =  $countEat/$countRows;

        //determine the average of people like to watch movies:
        $sqlMov="SELECT SUM(watchMovies) AS countMov FROM activity";
        $movResult =mysqli_query($conn,$sqlMov);
        $valueMov = mysqli_fetch_assoc($movResult);
        $countMov=$valueMov['countMov'];
        $movAve =  $countMov/$countRows;

        //determine the average of people like to watch TV:
        $sqlWat="SELECT SUM(watchTV) AS countWat FROM activity";
        $watResult =mysqli_query($conn,$sqlWat);
        $valueWat = mysqli_fetch_assoc($watResult);
        $countWat=$valueWat['countWat'];
        $watAve =  $countWat/$countRows;

        //determine the average of people like to listen to the radio:
        $sqlRad="SELECT SUM(likeRadio) AS countRad FROM activity";
        $radResult =mysqli_query($conn,$sqlRad);
        $valueRad = mysqli_fetch_assoc($radResult);
        $countRad=$valueRad['countRad'];
        echo $countRad;
        $radAve =  $countRad/$countRows;
  ?>

<div class = "head7"><h1>The results of the surveys</h1><br>
<div class= "perDe">
<h3>Total number of surveys:&nbsp;<?php echo $num_rows ?></h3>
<h3>Average age:&nbsp;<?php echo $ave ?></h3>
<h3>Oldest person who participated in survey:&nbsp;<?php echo $maxAge ?></h3>
<h3>Youngest person who participated in survey:&nbsp;<?php echo $minAge ?></h3>
<br>
<br>
<br>
<h3>Percentage of people who like Pizza:&nbsp;<?php echo round($perPizza) ?> % </h3>
<h3>Percentage of people who like Pasta:&nbsp;<?php echo round($perPasta) ?> % </h3>
<h3>Percentage of people who like Pap and Wors:&nbsp;<?php echo round($perPap) ?> % </h3>
<br>
<br>
<br>
<h3>People like to eat out:&nbsp;<?php echo $eatAve ?></h3>
<h3>People like to watch movies:&nbsp;<?php echo $movAve ?></h3>
<h3>People like to watch TV:&nbsp;<?php echo $watAve ?></h3>
<h3>People like to listen to the radio:&nbsp;<?php echo $radAve ?></h3>

<button Class="btn btn2" onclick="resultsToHome()">OK</button>

<script>
    function resultsToHome()
        {
            window.location = "welcom.html";
        }
</script>
           
</div>
</body>
</html>